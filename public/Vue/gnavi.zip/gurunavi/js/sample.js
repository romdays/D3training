var param = {
  keyid: "278994db4d7d72569dc93a2f112f9d0c",
  name: "niku",
  format: 'json',
  latitude: 35.670083,
  longitude: 139.763267,
  range: 1,
}

const testAxios = axios.create({
  headers: {
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  },
  responseType: 'json',
  withCredentials:true
});

var searchBox = {
  props: ['value'],
  // data: function(){
  //   return {info: null}
  // },
  template: `
  <div>
      <input
        type="text"
        v-bind:value="value"
        v-on:input="$emit('input', $event.target.value)"
        placeholder="input keyword"
      >
      <button v-on:click="$emit('get-info')">search</button>
      </div>
  `
}

var searchResult = {
  props: ['json'],
  template:`
    <div>
      <a href="json.url"> {{json.name}} </a>
      <p> {{json.pr_short}} </p>
      <img border="1" src="json.image_url.shop_image1" width="128" height="128" alt="json.name">
    </div>
  `
}


var vm = new Vue({
  data: {
    searchText: "",
    info: null,
  },
  components: {
    'search-box': searchBox,
  },
  methods: {
    getInfo: function(){
      testAxios
      //.get('https://api.gnavi.co.jp/RestSearchAPI/v3/?keyid=278994db4d7d72569dc93a2f112f9d0c&name=niku')
      .post('https://api.gnavi.co.jp/RestSearchAPI/v3/', param)
      .then(response => (this.info = response))
      .catch(error => console.log(error))
    }
  },
}).$mount('#app')